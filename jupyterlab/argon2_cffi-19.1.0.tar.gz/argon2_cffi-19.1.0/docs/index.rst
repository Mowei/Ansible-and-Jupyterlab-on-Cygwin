``argon2_cffi``
===============

Release v\ |release| (:doc:`What's new? <changelog>`).


.. include:: ../README.rst
   :start-after: teaser-begin


User's Guide
------------

.. toctree::
   :maxdepth: 1

   argon2
   installation
   api
   parameters
   cli
   faq


Project Information
-------------------

.. toctree::
   :maxdepth: 1

   backward-compatibility
   contributing
   changelog
   license


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
